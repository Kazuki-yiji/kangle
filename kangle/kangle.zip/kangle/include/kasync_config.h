#define KSOCKET_SSL
/* #undef KSOCKET_SSL_BIO */
#define LINUX
/* #undef LINUX_IOURING */
#define HAVE_ACCEPT4
/* #undef KASYNC_TEST */
#ifdef HAVE_ACCEPT4
#undef _GNU_SOURCE
#define _GNU_SOURCE
#endif
